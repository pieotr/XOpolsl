var class_game_state_controller =
[
    [ "EndTurn", "class_game_state_controller.html#a2129f5bbaa3f7fd1588dfbdc2f42bb42", null ],
    [ "GetPlayerSprite", "class_game_state_controller.html#abc5630bead93233a8626a85c432dd95b", null ],
    [ "GetPlayersTurn", "class_game_state_controller.html#a2c9683c3397653bdc67ed8412f250bd3", null ],
    [ "RestartGame", "class_game_state_controller.html#aa01e99ca9f80bf13ddd888d373b9a3cc", null ],
    [ "SetNewStartingPlayer", "class_game_state_controller.html#aa81c0a4d6075d2f9bb672a8bd44edb97", null ],
    [ "activePlayerColor", "class_game_state_controller.html#a4e8e477eb45c8e6a30e4b7a61e8a8bfe", null ],
    [ "endGameState", "class_game_state_controller.html#a06db76fc96d48f7385b47e8a4c8165f4", null ],
    [ "inactivePlayerColor", "class_game_state_controller.html#a0437546cff6f6735f4c44f6f86fc08d6", null ],
    [ "player1InputField", "class_game_state_controller.html#a163315c2723600c77f5cce864517339f", null ],
    [ "player2InputField", "class_game_state_controller.html#ae500e348ff066310b8844f36c4ec6dbd", null ],
    [ "playerOIcon", "class_game_state_controller.html#afd77657e0ab45a46fcc664328546b088", null ],
    [ "playerXIcon", "class_game_state_controller.html#a1126c8ae0384ff1aab1434e570d8b708", null ],
    [ "tileEmpty", "class_game_state_controller.html#a38c6b2bd3b152b55527951434d9b3378", null ],
    [ "tileList", "class_game_state_controller.html#a5cd4af6ec4a6c7787602287d0b02c0d7", null ],
    [ "tilePlayerO", "class_game_state_controller.html#a0455092a0cfbaea4ec87f30060f2283f", null ],
    [ "tilePlayerX", "class_game_state_controller.html#a27261b725259fa91f320981e14c2fb74", null ],
    [ "whoPlaysFirst", "class_game_state_controller.html#a1c2aa825963c2d06b7b62784b2b29669", null ],
    [ "winnerText", "class_game_state_controller.html#a88ac3bc5b7a83fe359986233f7cf372c", null ]
];