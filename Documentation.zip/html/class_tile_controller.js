var class_tile_controller =
[
    [ "ResetTile", "class_tile_controller.html#aab73d63e3b9d7617afee48f357ba86fa", null ],
    [ "UpdateTile", "class_tile_controller.html#afffb84c8d0d69c8d3b2b6e8a01d2af4e", null ],
    [ "gameController", "class_tile_controller.html#a9b000a706d31805b5894662e35ed870e", null ],
    [ "interactiveButton", "class_tile_controller.html#aad873777c0b6957c4a8d688fc83f2008", null ],
    [ "internalText", "class_tile_controller.html#a091bced26b40881818f0292efdeb07e0", null ]
];