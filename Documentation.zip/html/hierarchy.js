var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "GameStateController", "class_game_state_controller.html", null ],
      [ "TileController", "class_tile_controller.html", null ]
    ] ]
];