var searchData=
[
  ['activeplayercolor_0',['activePlayerColor',['../class_game_state_controller.html#a4e8e477eb45c8e6a30e4b7a61e8a8bfe',1,'GameStateController']]]
];
