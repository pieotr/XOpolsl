var searchData=
[
  ['endgamestate_0',['endGameState',['../class_game_state_controller.html#a06db76fc96d48f7385b47e8a4c8165f4',1,'GameStateController']]],
  ['endturn_1',['EndTurn',['../class_game_state_controller.html#a2129f5bbaa3f7fd1588dfbdc2f42bb42',1,'GameStateController']]]
];
