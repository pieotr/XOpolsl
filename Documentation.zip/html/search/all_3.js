var searchData=
[
  ['inactiveplayercolor_0',['inactivePlayerColor',['../class_game_state_controller.html#a0437546cff6f6735f4c44f6f86fc08d6',1,'GameStateController']]],
  ['interactivebutton_1',['interactiveButton',['../class_tile_controller.html#aad873777c0b6957c4a8d688fc83f2008',1,'TileController']]],
  ['internaltext_2',['internalText',['../class_tile_controller.html#a091bced26b40881818f0292efdeb07e0',1,'TileController']]]
];
