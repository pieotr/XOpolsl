var searchData=
[
  ['resettile_0',['ResetTile',['../class_tile_controller.html#aab73d63e3b9d7617afee48f357ba86fa',1,'TileController']]],
  ['restartgame_1',['RestartGame',['../class_game_state_controller.html#aa01e99ca9f80bf13ddd888d373b9a3cc',1,'GameStateController']]]
];
