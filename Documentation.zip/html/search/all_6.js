var searchData=
[
  ['setnewstartingplayer_0',['SetNewStartingPlayer',['../class_game_state_controller.html#aa81c0a4d6075d2f9bb672a8bd44edb97',1,'GameStateController']]]
];
