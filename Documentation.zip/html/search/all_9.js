var searchData=
[
  ['whoplaysfirst_0',['whoPlaysFirst',['../class_game_state_controller.html#a1c2aa825963c2d06b7b62784b2b29669',1,'GameStateController']]],
  ['winnertext_1',['winnerText',['../class_game_state_controller.html#a88ac3bc5b7a83fe359986233f7cf372c',1,'GameStateController']]]
];
