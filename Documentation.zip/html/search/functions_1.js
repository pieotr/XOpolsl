var searchData=
[
  ['getplayersprite_0',['GetPlayerSprite',['../class_game_state_controller.html#abc5630bead93233a8626a85c432dd95b',1,'GameStateController']]],
  ['getplayersturn_1',['GetPlayersTurn',['../class_game_state_controller.html#a2c9683c3397653bdc67ed8412f250bd3',1,'GameStateController']]]
];
